#this is the script to run EmoPy:s pretrained fermodel to classify emotions of a bunch of faces for the 
#To run this you need to install EmoPy following the instructions here: https://github.com/thoughtworksarts/EmoPy and then replacing the
#fermodel.py file in EmoPy/src with the one prowided
#portrait project of the random team on the course computational creativity spring 2019. The rootdir path should be changed to the
#position of the images to be classified. 
#this file was run from the folder Emopy/examplles, if you use a different folder, see that the import pats are surely right.
#the course project requirements do not contain everything needed for this, and that was why it was prerun separetly

from EmoPy.src.fermodel import FERModel
from pkg_resources import resource_filename
import pandas as pd

import os
rootdir = 'sample/'

target_emotions1 = ['surprise', 'anger', 'calm', 'fear']
target_emotions2 = ['calm', 'anger', 'happiness']
#removed doe to almost always returning happines, our dataset of ffhq is inherently mostly happy faces, and no really disgusted ones
#target_emotions3 = ['happiness', 'disgust', 'surprise']
target_emotions4 = ['happiness', 'anger', 'calm']
target_emotions5 = ['disgust', 'anger', 'fear']
target_emotions6 = ['surprise', 'disgust', 'calm']
target_emotions7 = ['sadness', 'surprise', 'disgust']

#suprise 4
#anger 4
#calm 4
#fear 2
#happiness 3
#disgust 4
#sadness 1

model = FERModel(target_emotions1, verbose=False)
model2 = FERModel(target_emotions2, verbose=False)
#model3 = FERModel(target_emotions3, verbose=False)
model4 = FERModel(target_emotions4, verbose=False)
model5 = FERModel(target_emotions5, verbose=False)
model6 = FERModel(target_emotions6, verbose=False)
model7 = FERModel(target_emotions7, verbose=False)

df = pd.DataFrame(columns=['anger', 'fear', 'sadness', 'happiness', 'surprise', 'disgust', 'calm'])
all_emotions = ['anger', 'fear', 'sadness', 'happiness', 'surprise', 'disgust', 'calm']





for subdir, dirs, files in os.walk(rootdir):
    for file in files:
        #print os.path.join(subdir, file)
        imagePath = rootdir + file

        if imagePath.endswith(".png"):
            emotions = []




            #print('Predicting on suprise,anger, calm, fear')
            #model.predict(resource_filename('EmoPy.examples','image_data/sample_happy_image.png'))
            emotions.append(model.predict(resource_filename('EmoPy.examples',imagePath)))

            #print('Predicting on calm, anger, happines')
            emotions.append(model2.predict(resource_filename('EmoPy.examples',imagePath)))

            #print('Predicting on happiness, disgust, surprise')
            #emotions.append(model3.predict(resource_filename('EmoPy.examples',imagePath)))

            #print('Predicting on happiness, anger, calm')
            emotions.append(model4.predict(resource_filename('EmoPy.examples',imagePath)))

            #print('Predicting on disgust, anger, fear')
            emotions.append(model5.predict(resource_filename('EmoPy.examples',imagePath)))

            #print('Predicting on surprise, disgust, calm')
            emotions.append(model6.predict(resource_filename('EmoPy.examples',imagePath)))

            #print('Predicting on sadness, surprise, disgust')
            emotions.append(model7.predict(resource_filename('EmoPy.examples',imagePath)))


            print('e', emotions)
            emotions = list(set(emotions) - set(['None']))
            print('noDub', emotions)

            for emo in all_emotions:
                if emo in emotions:
            	    df.ix[file,emo]=1
                else:
            	    df.ix[file,emo]=0
df.to_csv('face_emotions.csv', index_label = 'file')

print(df)

